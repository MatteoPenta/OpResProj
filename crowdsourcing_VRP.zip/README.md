# Crowdsourcing VRP

*Dummy Agent*: it returns the delivery in the same order as their arrival

*exactVRPAgent:*

- Decide which delivery to crowdship based on the l2 distance 
- Solve in an exact way the VRP by means of Lazy constraints

